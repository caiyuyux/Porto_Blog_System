$('.post-list').easyPaginate({
    firstButton: false,
    lastButton: false,
    prevButton: false,
    nextButton: false,
    paginateElement: 'article',
    elementsPerPage: 3
});